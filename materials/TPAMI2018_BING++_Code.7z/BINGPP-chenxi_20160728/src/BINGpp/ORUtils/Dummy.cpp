// Copyright 2014 Isis Innovation Limited and the authors of InfiniTAM

void dummy_with_external_linkage() {}

